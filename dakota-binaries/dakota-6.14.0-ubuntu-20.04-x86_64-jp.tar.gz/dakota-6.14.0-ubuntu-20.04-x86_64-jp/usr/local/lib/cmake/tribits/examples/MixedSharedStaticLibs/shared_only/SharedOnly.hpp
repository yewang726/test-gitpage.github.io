#ifndef SHAREDONLY_HPP_
#define SHAREDONLY_HPP_

#include <string>

namespace MixedSharedStaticLibs {

std::string sharedPassThrough(const std::string &str);

}

#endif /* SHAREDONLY_HPP_ */

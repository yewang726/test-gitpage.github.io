/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef StarSTL_VERSION_H
#define StarSTL_VERSION_H

#define StarSTL_VERSION_MAJOR 0
#define StarSTL_VERSION_MINOR 3
#define StarSTL_VERSION_PATCH 3

#endif  /* StarSTL_VERSION_H */


/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef StarCPR_VERSION_H
#define StarCPR_VERSION_H

#define StarCPR_VERSION_MAJOR 0
#define StarCPR_VERSION_MINOR 1
#define StarCPR_VERSION_PATCH 2

#endif  /* StarCPR_VERSION_H */


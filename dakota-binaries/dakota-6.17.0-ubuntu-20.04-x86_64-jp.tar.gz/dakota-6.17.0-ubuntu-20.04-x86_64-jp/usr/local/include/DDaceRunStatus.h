#ifndef DDACERUNSTATUS_H
#define DDACERUNSTATUS_H

enum DDaceRunStatus {DDaceRunOK, DDaceRunFailed, DDacePostProcFailed, 
										 DDaceRunNotStarted, DDaceRunPending};

#endif

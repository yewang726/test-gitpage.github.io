# Need: dprepro, python on path

# For debugging
#Set-PSDebug -Trace 1

# $1 and $2 are special variables in bash that contain the 1st and 2nd 
# command line arguments to the script, which are the names of the
# Dakota parameters and results files, respectively.

$params=$args[0]
$results=$args[1]

############################################################################### 
##
## Pre-processing Phase -- Generate/configure an input file for your simulation 
##  by substiting in parameter values from the Dakota paramters file.
##
###############################################################################

# TODO

############################################################################### 
##
## Execution Phase -- Run your simulation
##
###############################################################################


./cantilever cantilever.i > cantilever.log

############################################################################### 
##
## Post-processing Phase -- Extract (or calculate) quantities of interest
##  from your simulation's output and write them to a properly-formatted
##  Dakota results file.
##
###############################################################################

# TODO

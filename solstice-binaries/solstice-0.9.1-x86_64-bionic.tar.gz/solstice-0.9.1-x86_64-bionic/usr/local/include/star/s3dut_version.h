/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef Star3DUT_VERSION_H
#define Star3DUT_VERSION_H

#define Star3DUT_VERSION_MAJOR 0
#define Star3DUT_VERSION_MINOR 3
#define Star3DUT_VERSION_PATCH 2

#endif  /* Star3DUT_VERSION_H */


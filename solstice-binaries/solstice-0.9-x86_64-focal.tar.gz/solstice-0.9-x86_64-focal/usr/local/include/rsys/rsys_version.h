/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef RSys_VERSION_H
#define RSys_VERSION_H

#define RSys_VERSION_MAJOR 0
#define RSys_VERSION_MINOR 12
#define RSys_VERSION_PATCH 0

#endif  /* RSys_VERSION_H */


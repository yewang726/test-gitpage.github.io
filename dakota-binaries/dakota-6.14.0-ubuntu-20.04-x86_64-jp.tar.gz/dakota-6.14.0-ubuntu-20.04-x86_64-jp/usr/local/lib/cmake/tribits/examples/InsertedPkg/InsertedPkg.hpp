#ifndef INSERTEDPKG_HPP_
#define INSERTEDPKG_HPP_

#include <string>

namespace InsertedPkg {

  std::string deps();

}

#endif /* INSERTEDPKG_HPP_ */

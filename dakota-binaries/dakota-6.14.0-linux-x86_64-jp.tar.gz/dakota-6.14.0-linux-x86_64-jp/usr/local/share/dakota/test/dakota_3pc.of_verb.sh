#!/bin/sh
#
# Output Filter Script for testing verbatim 3 piece file management
#
mv workdir/tb.out ./tb.out
rm -rf workdir

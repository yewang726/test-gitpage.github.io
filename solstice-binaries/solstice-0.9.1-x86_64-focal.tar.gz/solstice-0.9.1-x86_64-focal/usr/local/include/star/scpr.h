/* Copyright (C) |Meso|Star> 2016 (contact@meso-star.com)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>. */

#ifndef SCPR_H
#define SCPR_H

#include <rsys/rsys.h>

/* Library symbol management */
#if defined(SCPR_SHARED_BUILD) /* Build shared library */
  #define SCPR_API extern EXPORT_SYM
#elif defined(SCPR_STATIC_BUILD) /* Use/build static library */
  #define SCPR_API extern LOCAL_SYM
#else /* Use shared library */
  #define SCPR_API extern IMPORT_SYM
#endif

/* Helper macro that asserts if the invocation of the scpr function `Func'
 * returns an error. */
#ifndef NDEBUG
  #define SCPR(Func) ASSERT(scpr_##Func == RES_OK)
#else
  #define SCPR(Func) scpr_##Func
#endif

enum scpr_operation {
  SCPR_AND, /* Keep the mesh part that intersects the clip polygon */
  SCPR_SUB, /* Remove the mesh part that intersects the clip polygon */
  SCPR_OPERATIONS_COUNT__
};

/* Public polygon data type. Define the list of the countour vertices. */
struct scpr_polygon {
  void (*get_position)(const size_t ivert, double pos[2], void* ctx);
  size_t nvertices; /* #vertices */
  /* User data provided as the last argument of the get_position functor */
  void* context;
};
#define SCPR_POLYGON_NULL__ { NULL, 0, NULL }
static const struct scpr_polygon SCPR_POLYGON_NULL = SCPR_POLYGON_NULL__;

/* Forward declaration */
struct mem_allocator;

/* Opaque 2D mesh data type */
struct scpr_mesh;

BEGIN_DECLS

SCPR_API res_T
scpr_mesh_create
  (struct mem_allocator* allocator, /* May be NULL <=> Use default allocator */
   struct scpr_mesh** mesh);

SCPR_API res_T
scpr_mesh_ref_get
  (struct scpr_mesh* mesh);

SCPR_API res_T
scpr_mesh_ref_put
  (struct scpr_mesh* mesh);

SCPR_API res_T
scpr_mesh_setup_indexed_vertices
  (struct scpr_mesh* mesh,
   const size_t ntris, /* #triangles */
   void (*get_indices)(const size_t itri, size_t ids[3], void* ctx),
   const size_t nverts, /* #vertices */
   void (*get_position)(const size_t ivert, double pos[2], void* ctx),
   void* data); /* Client data set as the last param of the callbacks */

/* Clip the mesh against the polygon contour */
SCPR_API res_T
scpr_mesh_clip
  (struct scpr_mesh* mesh, /* Candidate mesh to clip */
   const enum scpr_operation op, /* Clip operation */
   struct scpr_polygon* polygon); /* Clip polygon */

SCPR_API res_T
scpr_mesh_get_triangles_count
  (const struct scpr_mesh* mesh,
   size_t* ntris);

SCPR_API res_T
scpr_mesh_get_vertices_count
  (const struct scpr_mesh* mesh,
   size_t* nverts);

SCPR_API res_T
scpr_mesh_get_indices
  (const struct scpr_mesh* mesh,
   const size_t itri,
   size_t ids[3]);

SCPR_API res_T
scpr_mesh_get_position
  (const struct scpr_mesh* mesh,
   const size_t ivert,
   double position[2]);

END_DECLS

#endif /* SCPR_H */


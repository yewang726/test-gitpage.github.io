# Star 3D

## Overview

Star-3D is a C library that *manages surfacic geometries* and provides
operators to access them efficiently by *uniform sampling*, *ray-tracing* or a
*closest point query*. To ensure the efficiency of these operators, Star-3D
internally relies on [Intel(R) Rendering
Framework](https://software.intel.com/en-us/rendering-framework):
[Embree](https://embree.github.io) that provides highly optimized acceleration
structures as well as traversal kernels for a wide range of data workloads. The
main targets of Star-3D are thus programmers that want to efficiently handle
*complex and arbitrary 3D content.*

The main concept exposed in Star-3D is the *shape*. A shape represents a 3D
object such as a *triangular mesh* or a *sphere*, whose data are user defined
and can be updated at any time. A virtual environment is built by attaching one
or several shapes to a *scene*. A scene can be *instantiated* into one or
several shapes that can be then attached to a scene as any regular shapes. Each
instance has its own position and orientation while the instantiated geometry
is stored once even though it is instantiated several times. This feature can
thus be used to create extremely complex environment with a low memory
footprint.

To query the scene data one has to create a *view* of the scene. On its
creation, the view internally builds data structures required by the
aforementioned access operators. These data structures are built from the scene
geometry as defined at the moment of the view creation; a view is thus
insensitive to scene updates following its creation. This means that several
views can be used to register different states of the same scene, giving to the
caller a great flexibility to manage the scene data.

Star-3D is currently used in several projects dealing with complex arbitrary 3D
contents, ranging from graphics applications and thermal simulations to
electromagnetism. Please refer to these projects for informations on their
purpose.

  * [High-Tune: RenDeRer](https://gitlab.com/meso-star/htrdr.git)
  * [Stardis-Solver](https://gitlab.com/meso-star/stardis-solver.git)
  * [Solstice-Solver](https://gitlab.com/meso-star/solstice-solver.git)
  * [Star-4V/S](https://gitlab.com/meso-star/star-4v_s.git)
  * [Star-GebhartFactor](https://gitlab.com/meso-star/star-gf.git)
  * [Star-Schiff](https://gitlab.com/meso-star/star-schiff.git)

## Install

### Pre-requisites

Star-3D is compatible GNU/Linux as well as Microsoft Windows 7 and later, both
in 64-bits. It was successfully built with the [GNU Compiler
Collection](https://gcc.gnu.org) (versions 4.9.2 and later) as well as with
Microsoft Visual Studio 2015. It relies on [CMake](http://www.cmake.org) and the
[RCMake](https://gitlab.com/vaplv/rcmake/) package to build. It also depends on
the [RSys](https://gitlab.com/vaplv/rsys/) and
[Embree](https://embree.github.io/) libraries.

### How to build

First ensure that CMake and a C/C++ compiler is installed on your system. Then
install the [RCMake](https://gitlab.com/vaplv/rcmake.git) package as well as
the [RSys](https://gitlab.com/vaplv/rsys.git) and
[Embree](https://embree.github.io) libraries. Finally generate the project from
the `cmake/CMakeLists.txt` file by appending to the `CMAKE_PREFIX_PATH`
variable the `<RCMAKE_DIR>`, `<RSYS_DIR>` and `<EMBREE_DIR>`
directories, where `<RCMAKE_DIR>`, `<RSYS_DIR>` and `<EMBREE_DIR`> are the
install directories of the RCMake package, the RSys and the Embree libraries,
respectively. The resulting project can be edited, built, tested and installed
as any CMake project (Refer to the [CMake
documentation](https://cmake.org/documentation) for further informations on
CMake).

Example on a GNU/Linux system:

    ~ $ git clone https://gitlab.com/meso-star/star-3d.git
    ~ $ mkdir star-3d/build && cd star-3d/build
    ~/star-3d/build $ cmake -G "Unix Makefiles" \
    > -DCMAKE_PREFIX_PATH="<RCMAKE_DIR>;<RSYS_DIR>;<EMBREE_DIR>" \
    > -DCMAKE_INSTALL_PREFIX=<STAR3D_INSTALL_DIR> \
    > ../cmake
    ~/star-3d/build $ make && make test
    ~/star-3d/build $ make install

with `<STAR3D_INSTALL_DIR>` the directory in which Star-3D is going to be
installed.

## Quick Start

Once installed, the Star-3D library and its associated headers are deployed,
providing the whole environment required to develop C/C++ applications with
Star-3D. The `<STAR3D_INSTALL_DIR>/include/star/s3d.h` header defines the
Star-3D Application Programming Interface (API). Refer to this
[file](https://gitlab.com/meso-star/star-3d/blob/master/src/s3d.h) for the API
reference documentation.

A Star-3D [CMake
package](https://cmake.org/cmake/help/v3.5/manual/cmake-packages.7.html) is
also installed to facilitate the use of Star-3D in projects relying on the
CMake build system. For instance, the following `CMakeLists.txt` file uses the
Star-3D package to build an executable relying on the Star-3D library.

    project(my_project C)

    # Use the Star-3D CMake package
    find_package(Star3D REQUIRED)
    include_directories(${Star3D_INCLUDE_DIR})

    # Define the program to build
    add_executable(my_program main.c)

    # Link the program against Star-3D
    target_link_libraries(my_program Star3D)

This `CMakeLists.txt` is then used to generate the target project as, for
instance, on a GNU/Linux system:

    cmake -G "Unix Makefiles" -DCMAKE_PREFIX_PATH="<STAR3D_INSTALL_DIR>" <MY_PROJECT_DIR>

with `<STAR3D_INSTALL_DIR>` the install directory of Star-3D and
`<MY_PROJECT_DIR>` the location of the `CMakeLists.txt` file.

## Release notes

### Version 0.8.1

Fix compilation warnings with GCC 11

### Version 0.8

Update the API of the filtering function: add the range of the ray as input
argument. For closest point queries, this range is from 0 to query radius.

### Version 0.7.4

- Fix the barycentric coordinates of the intersection of the ray onto the
  triangle: the coordinates could lie outside the triangle.
- Fix compilation warnings.

### Version 0.7.3

- Fix the `s3d_scene_view_closest_point` function on the scenes containing
  instantiated meshes: the rotation of the instances was wrongly taken into
  account.
- Speed up the `s3d_scene_view_closest_point` query on instantiated meshes.

### Version 0.7.2

- Fix a precision issue in the `s3d_scene_view_closest_point` function: the
  returned hit could have invalid barycentric coordinates.

### Version 0.7.1

- Fix an invalid memory read at the setup of the scene view when the
  `S3D_TRACE` flag was set. The Embree backend assumes that the last vertex
  position is at least 16 bytes length while its size was only of 12 bytes
  (i.e. 3 single-precision floating-point values).

### Version 0.7

- Add the `s3d_scene_view_closest_point` function. This function retrieves the
  closest point into the scene to a query position in a radius from ]0, INF].
  This closest point is returned as a regular hit which means that the function
  returns to the caller not only the distance to the query position, but also
  the geometric primitive onto which the point lies and its location onto this
  primitive. If no surface lies around the query position in a distance lesser
  than the one defined by the query radius, the returned hit is invalid which
  can be checked with the regular `S3D_HIT_NONE` macro. Finally, this function
  supports the filter functions so that the caller can choose to discard
  closest hits according to its own criteria.
- Add the `s3d_scene_view_create2` function that allows the user to configure
  the acceleration structure used to partition the scene geometry. The caller
  can thus control the quality of the structure and thus the compromise between
  the building time and the query performances.
- Improve the performances of the scene bounding box computation. First of all,
  if the scene view is created with the `S3D_TRACE` flag, Star-3D directly
  retrieves the scene bounding box from Embree that already computed it to
  build the acceleration structure. Finally, it internally tries to avoid to
  recompute the bounding box if the scene was not updated between 2 scene view
  creations.

### Version 0.6.2

- Fix an issue in `s3d_scene_view_compute_area`: the returned area was wrong
  when the scene view was created with the `S3D_SAMPLE` flag.

### Version 0.6.1

- Fix an issue in `s3d_scene_view_sample`: the samples were not uniformly
  distributed if the scene contained meshes and spheres.

### Version 0.6

- Migrate the ray-tracing back-end from Embree2 to Embree3.

### Version 0.5.1

- Fix a compilation issue on VC2017.

### Version 0.5

- Add the support of spherical shapes. A sphere is composed of one primitive
  that can be sampled and/or ray-traced as any other primitives of the scene.
  Hit filtering is also fully supported.

### Version 0.4.2

- Update the version of the RSys dependency to 0.6: replace the deprecated
  `[N]CHECK` macros by the new macro `CHK`.

### Version 0.4.1

- Fix the `s3d_scene_view` consistency when it is created from a scene
  containing instances: the geometries might be not correctly synchronised and
  thus could be outdated.

### Version 0.4

- Implement the `s3d_scene_view` API; it replaces the
  `s3d_scene_<begin|end>_session` functions that were removed. A view registers
  the state of the scene from which it is created. It is used to retrieve the
  scene data through ray-tracing, sampling or indexing. Several views can be
  created on the same scene.
- Add the possibility to attach a same shape to several scenes.
- Fix a memory overconsumption with instantiated shapes: the instantiated
  back-end data were copied rather than shared.
- Add the `s3d_scene_shapes_count` function that returns the overall number of
  shapes in the scene.
- Add the `s3d_instance_set_transform` and `s3d_instance_transform` functions
  that sets or gets the transformation matrix of the instance, respectively.
- Add the `s3d_primitive_get_transform` function that gets the transformation
  matrix of a primitive.
- Add the `s3d_primitive_has_attrib` function that returns if a primitive has a
  specific attribute or not.
- Add the `s3d_triangle_get_vertex_attrib` function that retrieves the
  vertex attributes of a triangular primitive.

## License

Copyright (C) 2015-2021, 2023 |Méso|Star> (<contact@meso-star.com>). Star-3D is
released under the CeCILLv2.1 license. You are welcome to redistribute it under
certain conditions; refer to the COPYING files for details.


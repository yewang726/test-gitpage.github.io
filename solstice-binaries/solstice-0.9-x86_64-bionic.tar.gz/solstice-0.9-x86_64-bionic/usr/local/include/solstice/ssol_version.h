/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef SolSolver_VERSION_H
#define SolSolver_VERSION_H

#define SolSolver_VERSION_MAJOR 0
#define SolSolver_VERSION_MINOR 8
#define SolSolver_VERSION_PATCH 0

#endif  /* SolSolver_VERSION_H */


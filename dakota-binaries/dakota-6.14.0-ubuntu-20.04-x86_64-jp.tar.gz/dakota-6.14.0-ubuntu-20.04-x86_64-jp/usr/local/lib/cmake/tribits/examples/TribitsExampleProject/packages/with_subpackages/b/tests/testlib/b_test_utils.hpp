#ifndef WITHSUBPACKAGES_B_TEST_UTILS_HPP
#define WITHSUBPACKAGES_B_TEST_UTILS_HPP

#include <string>

namespace WithSubpackages {

std::string b_test_utils();

}

#endif // WITHSUBPACKAGES_B_TEST_UTILS_HPP


#ifndef VECTORCOUNTINGNUMBERSANDCOUNT_H_
#define VECTORCOUNTINGNUMBERSANDCOUNT_H_

#include <vector>

class VectorCountingNumbersAndCount {
	public:
	   std::vector<std::vector<int> > vectorCountingNumbers;
	   int count;
	   VectorCountingNumbersAndCount();
	   ~VectorCountingNumbersAndCount();
	   
};

#endif /*VECTORCOUNTINGNUMBERSANDCOUNT_H_*/

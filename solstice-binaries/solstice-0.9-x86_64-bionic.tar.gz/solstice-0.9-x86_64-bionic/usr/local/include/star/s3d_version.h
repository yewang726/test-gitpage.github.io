/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef Star3D_VERSION_H
#define Star3D_VERSION_H

#define Star3D_VERSION_MAJOR 0
#define Star3D_VERSION_MINOR 7
#define Star3D_VERSION_PATCH 4

#endif  /* Star3D_VERSION_H */


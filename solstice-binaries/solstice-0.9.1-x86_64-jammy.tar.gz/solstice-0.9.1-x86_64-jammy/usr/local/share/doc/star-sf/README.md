# Star-ScatteringFunctions

This library provides a set of abstractions to describe the way the light is
scattered with respect to a geometric optics model. It defines interfaces to
describe Bidirectional Scattering Distribution Functions, microfacet
distributions, Fresnel terms and phase functions. Several built-in
implementation of these interfaces are provided as specular, lambertian and
microfacet reflections, Beckmann and Blinn microfacet distributions,
dielectric/dielectric and dielectric/conductor Fresnel terms, Henyey &
Greenstein and Rayleigh phase functions, etc.

## How to build

The library uses [CMake](http://www.cmake.org) and the
[RCMake](https://gitlab.com/vaplv/rcmake/#tab-readme) package to build. It also
depends on the [Star-SP](https://gitlab.com/meso-star/star-sp/#tab-readme) and
the [RSys](https://gitlab.com/vaplv/rsys/#tab-readme) libraries. The
[RSIMD](https://gitlab.com/vaplv/rsimd) library is an optional dependency
which, if installed, is used to speed up the configuration of the RDG-FA phase
function.

First ensure that CMake is installed on your system. Then install the RCMake
package as well as all the aforementioned prerequisites. Finally generate the
project from the `cmake/CMakeLists.txt` file by appending to the
`CMAKE_PREFIX_PATH` variable the install directories of its dependencies.

## Release notes

### Version 0.8

Added support for discrete phase functions, i.e. phase functions whose values
are only defined for a set of angles.

### Version 0.7.2

Sets the required version of Star-SampPling to 0.12. This version fixes
compilation errors with gcc 11 but introduces API breaks.

### Version 0.7.1

Fix the evaluation of the RDG-FA phase function: the incident direction was
reversed.

### Version 0.7

Add a built-in phase function using the
[RDG-FA](https://doi.org/10.1016/j.jqsrt.2013.08.022) model.

### Version 0.6

- Add the phase function API allowing the user to define, sample and evaluate a
  phase function.
- Provide built-in implementation of the Henyey & Greenstein, and the Rayleigh
  phase functions.

### Version 0.5

- Add the pillbox microfacet distribution.
- Update the version of the RSys dependency to 0.6: replace the deprecated
  `[N]CHECK` macros by the new macro `CHK`.

### Version 0.4

- Fix the Blinn microfacet distribution.
- Change the microfacet distribution API to no longer require the unused
  outgoing direction parameter.
- Use and require Star-SamPling version 0.5.

### Version 0.3

- A BSDF is no more a composition of BxDFs: the caller writes directly the
  comportment of the BSDF without intermediary abstractions. As a result,
  built-in BxDFs become built-in BSDFs and the BxDF data structure and
  functions are removed from the API.

### Version 0.2

- Fix the thin-dielectric material to ensure the energy conservation property.
- Add the `ssf_specular_dielectric_dielectric_interface` BxDF. This scattering
  function could be built by combining the `ssf_specular_reflection` and the
  `ssf_specular_transmission` BxDFs into a BSDF but such combination does not
  ensure the energy conservation property due to weaknesses into the BSDF
  interface.

## License

Copyright (C) 2016-2018, 2021-2023 |Méso|Star> (<contact@meso-star.com>).
Star-ScatteringFunctions is free software released under the GPL v3+ license.
You are welcome to redistribute it under certain conditions; refer to the
COPYING file for details.


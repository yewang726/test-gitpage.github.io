//this file exists temporarily until we can remove all instances of
//-DHAVE_CONFIG_H from the CMake build of Dakota
//As a reminder, interfaces includes Opt.h, which includes this because
//HAVE_CONFIG_H is still defined for that package.

/*
#ifdef F77_FUNC
#undef F77_FUNC
#define F77_FUNC@FortranCInterface_GLOBAL_MACRO@
#else
#define F77_FUNC@FortranCInterface_GLOBAL_MACRO@
#endif
*/

int *ivector(), **imatrix();



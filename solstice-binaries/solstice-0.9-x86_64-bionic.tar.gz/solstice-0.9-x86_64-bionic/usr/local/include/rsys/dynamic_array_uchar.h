/* Copyright (C) 2013-2021 Vincent Forest (vaplv@free.fr)
 *
 * The RSys library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The RSys library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with the RSys library. If not, see <http://www.gnu.org/licenses/>. */

#ifndef DYNAMIC_ARRRAY_UCHAR_H
#define DYNAMIC_ARRRAY_UCHAR_H

#include "dynamic_array.h"

#define DARRAY_NAME uchar
#define DARRAY_DATA unsigned char
#include "dynamic_array.h"

#endif /* DYNAMIC_ARRRAY_UCHAR_H */

#!/bin/sh
#
# Analysis Driver Script for testing verbatim 3 piece file management
#
cd workdir
text_book tb.in tb.out

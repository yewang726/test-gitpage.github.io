#ifndef STATICONLY_HPP_
#define STATICONLY_HPP_

#include <string>

namespace MixedSharedStaticLibs {

std::string staticPassThrough(const std::string &str);

}

#endif /* STATICONLY_HPP_ */

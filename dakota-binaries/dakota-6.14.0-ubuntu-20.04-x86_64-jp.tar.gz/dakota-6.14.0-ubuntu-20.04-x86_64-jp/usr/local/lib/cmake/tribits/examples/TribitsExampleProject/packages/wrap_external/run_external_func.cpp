#include "external_func.hpp"
#include <iostream>

int main()
{
  std::cout << ExternalProj::external_func() << "\n";
}

#!/bin/sh
#
# Input Filter Script for testing verbatim 3 piece file management
#
mkdir workdir
mv tb.in workdir/tb.in

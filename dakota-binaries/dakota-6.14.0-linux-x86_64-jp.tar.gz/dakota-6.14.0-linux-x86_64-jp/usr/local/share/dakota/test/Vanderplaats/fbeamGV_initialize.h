//
// File: fbeamGV_initialize.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 23-Feb-2018 13:38:03
//
#ifndef FBEAMGV_INITIALIZE_H
#define FBEAMGV_INITIALIZE_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "fbeamGV_types.h"

// Function Declarations
extern void fbeamGV_initialize();

#endif

//
// File trailer for fbeamGV_initialize.h
//
// [EOF]
//

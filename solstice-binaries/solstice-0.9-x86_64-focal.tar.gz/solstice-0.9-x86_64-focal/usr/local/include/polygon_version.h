/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef Polygon_VERSION_H
#define Polygon_VERSION_H

#define Polygon_VERSION_MAJOR 0
#define Polygon_VERSION_MINOR 1
#define Polygon_VERSION_PATCH 2

#endif  /* Polygon_VERSION_H */


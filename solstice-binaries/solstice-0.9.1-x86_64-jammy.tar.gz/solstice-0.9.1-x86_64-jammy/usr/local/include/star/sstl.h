/* Copyright (C) |Meso|Star> 2015-2016 (contact@meso-star.com)
 *
 * This software is governed by the CeCILL license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 *
 * As a counterpart to the access to the source code and rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty and the software's author, the holder of the
 * economic rights, and the successive licensors have only limited
 * liability.
 *
 * In this respect, the user's attention is drawn to the risks associated
 * with loading, using, modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean that it is complicated to manipulate, and that also
 * therefore means that it is reserved for developers and experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or
 * data to be ensured and, more generally, to use and operate it in the
 * same conditions as regards security.
 *
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms. */

#ifndef SSTL_H
#define SSTL_H

#include <rsys/rsys.h>

/* Library symbol management */
#if defined(SSTL_SHARED_BUILD)
  #define SSTL_API extern EXPORT_SYM /* Build shared library */
#elif defined(SSTL_STATUC) /* Use/build statuc library */
  #define SSTL_API extern LOCAL_SYM
#else /* Use shared library */
  #define SSTL_API extern IMPORT_SYM
#endif

/* Helper macro that asserts if the invocation of the sstl function `Func'
 * returns an error. One should use this macro on sstl function calls for which
 * no explicit error checking is performed. */
#ifndef NDEBUG
  #define SSTL(Func) ASSERT(sstl_ ## Func == RES_OK)
#else
  #define SSTL(Func) sstl_ ## Func
#endif

/* Descriptor of a loaded STL */
struct sstl_desc {
  const char* solid_name; /* May be NULL <=> no name */

  /* Front faces are CCW ordered and the normals follow the right handed rule */
  const float* vertices; /* triangles_count * 3 coordinates */
  const unsigned* indices; /* triangles_count * 3 indices */
  const float* normals; /* Per triangle normalized normal */

  size_t triangles_count;
  size_t vertices_count;
};

/* Forward declaration of external types */
struct logger;
struct mem_allocator;

/* Forward declaration of opaque data types */
struct sstl;

/*******************************************************************************
 * Star-STL API
 ******************************************************************************/
BEGIN_DECLS

SSTL_API res_T
sstl_create
  (struct logger* logger, /* NULL <=> use default logger*/
   struct mem_allocator* allocator, /* NULL <=> use default allocator */
   const int verbose, /* Verbosity level */
   struct sstl** sstl);

SSTL_API res_T
sstl_ref_get
  (struct sstl* sstl);

SSTL_API res_T
sstl_ref_put
  (struct sstl* sstl);

SSTL_API res_T
sstl_load
  (struct sstl* sstl,
   const char* filename);

SSTL_API res_T
sstl_load_stream
  (struct sstl* sstl,
   FILE* stream);

/* The returned descriptor is valid until a new load process */
SSTL_API res_T
sstl_get_desc
  (const struct sstl* sstl,
   struct sstl_desc* desc);

END_DECLS

#endif /* SSTL_H */


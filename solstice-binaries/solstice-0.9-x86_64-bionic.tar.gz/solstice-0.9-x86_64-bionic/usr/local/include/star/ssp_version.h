/* Copying and distribution of this file, with or without modification,
 * are permitted in any medium without royalty provided the copyright
 * notice and this notice are preserved. This file is offered as-is,
 * without any warranty. */

#ifndef StarSP_VERSION_H
#define StarSP_VERSION_H

#define StarSP_VERSION_MAJOR 0
#define StarSP_VERSION_MINOR 11
#define StarSP_VERSION_PATCH 0

#endif  /* StarSP_VERSION_H */

